### 31 / 10 / 2016
### Tony Staunton
### Dictionaries Introduction

book_1 = {'author' : 'tony staunton', 'price' : 10}

print(book_1['author'])
print(book_1['price'])
