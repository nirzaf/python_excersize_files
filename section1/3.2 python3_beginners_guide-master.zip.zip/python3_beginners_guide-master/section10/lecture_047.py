
### Tony Staunton
### Using a key to get a value

# Create a dictionary of terms
terms = {}

terms['variable'] = 'Represents or refers to a value stored in memory.'
terms['integer'] = 'A whole number.'

print(terms['variable'])
print(terms['integer'])
