
### Tony Staunton
### Editing & deleting values in a dictionary

terms = {'integer' : 'Is a whole number.', 'string' : 'a sequence of characters.'}

print(terms.get('intger'))
print(terms.get('float', 'Not in the dictionary.'))
