book_1 = {
'name' : 'elon musk',
'author' : 'ashlee vance',
'price' : '14.99',
'publisher' : 'virgin books',
}

for key, value in book_1.items():
	print("\nKey: " + key)
	print("Value: " +value)
