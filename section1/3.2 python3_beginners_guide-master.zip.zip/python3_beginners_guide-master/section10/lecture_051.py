birthday_months = {
'tony' : 'november',
'deirdre' : 'may',
'niamh' : 'august',
}

for name in birthday_months.keys():
	print(name.title())
