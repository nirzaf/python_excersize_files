
### Tony Staunton
### Using the input prompt

prompt = "This is our lecture dicussing Python's input prompt and how to keep it tidy. Please enter your favorite lecture so far and why you like it?"

favorite_lecture = input(prompt)
