
### Tony Staunton
### Using while loops

current_number = 1
while current_number <= 10:
	print(current_number)
	current_number += 1
