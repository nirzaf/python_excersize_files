
# Tony Staunton
# Passing Information to a Function

def hello_world(username):
    """Showing a username"""
    print("Hello "+username.title()+".")

hello_world('tony')
