
# Tony Staunton
# Arbitrary Arguments

def create_passenger(*requests):
    """Print user requests"""
    print(requests)

create_passenger('window seat', 'seat near top of plane.')
