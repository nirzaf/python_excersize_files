
### Tony Staunton
### Importing a module

from books_to_buy import books_available

books_available('Elon Musk', 'The Everything Store')
