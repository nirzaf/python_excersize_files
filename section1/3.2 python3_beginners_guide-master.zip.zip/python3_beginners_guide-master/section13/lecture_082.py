
### Tony Staunton
### Importing a module

from books_to_buy import books_available as ba

print("This is our 1st function: ")
ba('Elon Musk')
