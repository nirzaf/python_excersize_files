first_name = 'tony'
last_name = 'staunton'

print(first_name)
print(last_name)