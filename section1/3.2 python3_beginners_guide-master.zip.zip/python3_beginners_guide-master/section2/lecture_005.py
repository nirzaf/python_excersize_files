name = "Tony Staunton"

name = 'Tony Staunton'

movie_line = 'What film is this? "Show me the money!"'

start = 'Let\'s get started with Python'

print(start)
