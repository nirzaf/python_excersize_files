first_name = "Tony"
last_name = "Staunton"

print("Hi " + first_name)

print("Dear Mr. " + last_name)

print(first_name + last_name)

print(first_name + " " + last_name)
