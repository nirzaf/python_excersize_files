name = "tony staunton"

first_name = "tony"
last_name = "staunton"

print(first_name.title())

print(name.title())

print(last_name.title())
