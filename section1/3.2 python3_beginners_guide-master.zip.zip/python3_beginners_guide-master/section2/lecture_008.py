my_book = "My favorite book is 'Elon Musk'.".find('Elon')

subject = "$$$ Get Rich Now $$$".find('$$$')
print(subject)