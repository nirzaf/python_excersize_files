name = "TONY STAUNTON".lower()
print(name)