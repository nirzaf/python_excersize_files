my_book = "My favorite book is 'Elom Musk'.".replace('Elom', 'Elon')
print(my_book)