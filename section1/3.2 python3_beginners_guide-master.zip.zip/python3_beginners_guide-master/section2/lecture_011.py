address = "102 Main Street		"
print(address.rstrip())

strip()

lstrip()

rstrip()