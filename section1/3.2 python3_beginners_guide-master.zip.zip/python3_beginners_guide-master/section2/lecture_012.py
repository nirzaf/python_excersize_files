address = "101 Main Streey \tDublin"
print(address)

address = "102 Main Street \nDublin"
print(address)
