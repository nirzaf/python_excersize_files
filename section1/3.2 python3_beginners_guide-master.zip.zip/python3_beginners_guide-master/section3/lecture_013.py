# The code in this file show be run in Python's IDLE or
# into the Python command line

2 + 2

5 - 3

3 * 3

6 / 2

3**3

5**5

2+3*4

(2+3)*4
