# The code in this file show be run in Python's IDLE or
# into the Python command line

1 + 1.0

2.0 * 3.0

3.0 / 2.0

0.2 + 0.1
