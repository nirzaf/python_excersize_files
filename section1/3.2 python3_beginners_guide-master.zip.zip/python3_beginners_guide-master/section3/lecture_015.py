
name = 'tony'.title()
date_today = 24
welcome_message = "Hi " + name + " welcome back, today's date is the " + str(date_today) + " of October."
print(welcome_message)

