months = ['january', 'february', 'march', 'april']

message = "I was born in " + months[3].title() + "."
print(message)