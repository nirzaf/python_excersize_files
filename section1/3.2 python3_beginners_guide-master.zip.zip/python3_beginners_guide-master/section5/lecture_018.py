#Creating a list of months
birthday_months = ['spril', 'may', 'november']

#Print the list
print(birthday_months)

#Change an element of the list
birthday_months[0] = 'april'

print(birthday_months)

#USe the append method
birthday_months.append('june')

print(birthday_months)

#Create an empty list
birthday_months = []

print(birthday_months)

birthday_months.append('august')

print(birthday_months)

#Use the insert method
birthday_months.insert(0, 'may')

print(birthday_months)

#Using the delete statement
del birthday_months[1]

print(birthday_months)
