### 25 / 10 / 2016
### Tony Staunton
### How to find the length of a list


# list of days of the week
birthday_days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']

print(len(birthday_days))

