# Looping through a list

months = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"]

# Using a loop to print a list
for month in months:
	print(month.title() + "\n")
	print("The next month is:")

print("Goodbye")
