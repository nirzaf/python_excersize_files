### 25 / 10 / 2016
### Tony Staunton
### The range function

# Using the range function
for value in range(1,6):
	print(value)



