### 25 / 10 / 2016
### Tony Staunton
### Slicing a list

names = ['tony', 'deirdre', 'senan', 'carol']
print(names[0:2])

print(names[1:3])

print(names[:3])

print(names[2:])

print(names[-3:])


