### 25 / 10 / 2016
### Tony Staunton
### Looping through a slice

# looping through a slice with a for loop

names = ['tony', 'fank', 'mary', 'carl']
print("Here are the names of the last 3 registrations.")
for name in names[:3]:
	print(name.title())





