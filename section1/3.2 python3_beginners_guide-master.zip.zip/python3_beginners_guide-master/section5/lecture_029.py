### 25 / 10 / 2016
### Tony Staunton
### Copying a list

names = ['tony', 'frank', 'mary', 'carl']
first_names = names[:]
print(first_names)

