### Tony Staunton
### Tuples

coordinates = (1001, 5002)
print("Original coordinates: ")
for coordinate in coordinates:
	print(coordinate)

coordinates = (2002, 7003)
print("\nNew coordinates: ")
for coordinate in coordinates:
	print(coordinate)



