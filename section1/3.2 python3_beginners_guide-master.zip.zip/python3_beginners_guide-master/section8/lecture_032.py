msg = input("whats your name?")
print("hello " + msg)