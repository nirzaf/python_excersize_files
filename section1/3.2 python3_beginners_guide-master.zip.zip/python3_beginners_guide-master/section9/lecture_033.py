

print("To continue please log in.")

# Using the if statement
password = input("Please enter your password.")
if password == "tony":
    print("Access granted.")
else:
    print("Incorrect. Please try again.")
