# The code below should be run in IDLE or directly in the Python command line.

password = 'tony'

password == 'tony'

output: True

password =='Tony'

output: False

password1 = 'Frank'
password1.lower() == 'frank'

output: True
