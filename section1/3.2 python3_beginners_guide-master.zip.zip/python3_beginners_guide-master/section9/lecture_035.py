
my_birthday = "November"

if my_birthday != 'March':
    print("It's not your birthday!")
