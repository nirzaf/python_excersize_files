age = 23
if age != 22:
    print("Sorry no cake for you.")
