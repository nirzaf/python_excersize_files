### 26 / 10 / 2016
### Tony Staunton
### Checking multiple conditions with the and condition

username = input("Welcome, please enter your username.")
password = input("Please enter your password.")

if username != 'tony' and password != 'password123':
    print("Access denied.")
else:
    print("Welcome.")
