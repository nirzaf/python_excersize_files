
# Create list of booking details
booking_details = ['tony', 'middle row', 'screen two']

if 'tony' in booking_details:
    print('Welcome to Udemy cinema')
if 'middle row'in booking_details:
    print('Your seat number is 010 in the middle row.')
if 'screen two' in booking_details:
    print('Your film is in screen two.')

