### 04 / 11 / 2016
### Tony Staunton
### How to define a function

def hello_world():
	"""Displaying hello world"""
	print("Hello World!")

hello_world()