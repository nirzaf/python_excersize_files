### 04 / 11 / 2016
### Tony Staunton
### Keyword Arguments

# Creating our function
def book_description(book_type, author):
	"""Display book information"""

	print("\nThis book is a " + book_type + " book.")
	print("The author of is " + author + ".")

book_description(book_type='non-fiction', author='brad stone')