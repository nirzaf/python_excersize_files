### 08 / 11 / 2016
### Tony Staunton
### Passing a list to a function

def books_available(book_titles):
	"""Show a list of books available to buy."""
	for book in book_titles:
		books_in_stock = "The following title is available: " + book.title() + "."
		print(books_in_stock)

available = ['elon musk', 'the everything store', 'the growth map']
books_available(available)