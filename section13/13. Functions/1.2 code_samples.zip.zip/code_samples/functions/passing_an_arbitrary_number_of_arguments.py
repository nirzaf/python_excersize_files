### 08 / 11 / 2016
### Tony Staunton
### Using arbitrary keyword arguments

def create_passenger(*requests):
	"""Print passenger requests."""
	print(requests)

create_passenger('window seat', 'seat near front of plane', 'breakfast')

