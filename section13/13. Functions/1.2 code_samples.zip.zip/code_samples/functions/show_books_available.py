### 10 / 11 / 2016
### Tony Staunton
### Importing a module

from books_to_buy import *

print("This is our 1st function: ")
books_available('The Everything Store')



