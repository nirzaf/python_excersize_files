### 10 / 11 / 2016
### Tony Staunton
### Importing a module

from books_to_buy_2 import book_description

book_description('ashlee vance')



