### 10 / 11 / 2016
### Tony Staunton
### Importing a module

from books_to_buy_2 import books_available as ba

print("This is our 1st function: ")
ba('Elon Musk')



