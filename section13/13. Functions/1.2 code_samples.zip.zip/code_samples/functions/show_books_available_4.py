### 10 / 11 / 2016
### Tony Staunton
### Importing a module

import books_to_buy as b2b

print("This is our 1st function: ")
b2b.books_available('The Everything Store')



